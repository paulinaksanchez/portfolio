
# API / NBA Data 


```python
!pip install nba_api

def one_dict(list_dict):
    keys=list_dict[0].keys()
    out_dict={key:[] for key in keys}
    for dict_ in list_dict:
        for key, value in dict_.items():
            out_dict[key].append(value)
    return out_dict    

import pandas as pd
import matplotlib.pyplot as plt

from nba_api.stats.static import teams
import matplotlib.pyplot as plt

nba_teams = teams.get_teams()

dict_nba_team=one_dict(nba_teams)
df_teams=pd.DataFrame(dict_nba_team)
df_teams.head()

df_warriors=df_teams[df_teams['nickname']=='Warriors']
df_warriors


```

    Requirement already satisfied: nba_api in /opt/conda/envs/Python36/lib/python3.6/site-packages (1.1.8)
    Requirement already satisfied: requests in /opt/conda/envs/Python36/lib/python3.6/site-packages (from nba_api) (2.21.0)
    Requirement already satisfied: urllib3<1.25,>=1.21.1 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (1.24.1)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2020.4.5.1)
    Requirement already satisfied: chardet<3.1.0,>=3.0.2 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (3.0.4)
    Requirement already satisfied: idna<2.9,>=2.5 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2.8)





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>full_name</th>
      <th>abbreviation</th>
      <th>nickname</th>
      <th>city</th>
      <th>state</th>
      <th>year_founded</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7</th>
      <td>1610612744</td>
      <td>Golden State Warriors</td>
      <td>GSW</td>
      <td>Warriors</td>
      <td>Golden State</td>
      <td>California</td>
      <td>1946</td>
    </tr>
  </tbody>
</table>
</div>




```python
from nba_api.stats.endpoints import leaguegamefinder


```


```python
! wget https://s3-api.us-geo.objectstorage.softlayer.net/cf-courses-data/CognitiveClass/PY0101EN/Chapter%205/Labs/Golden_State.pkl
```

    --2020-05-08 06:38:27--  https://s3-api.us-geo.objectstorage.softlayer.net/cf-courses-data/CognitiveClass/PY0101EN/Chapter%205/Labs/Golden_State.pkl
    Resolving s3-api.us-geo.objectstorage.softlayer.net (s3-api.us-geo.objectstorage.softlayer.net)... 67.228.254.196
    Connecting to s3-api.us-geo.objectstorage.softlayer.net (s3-api.us-geo.objectstorage.softlayer.net)|67.228.254.196|:443... connected.
    HTTP request sent, awaiting response... 200 OK
    Length: 811065 (792K) [application/octet-stream]
    Saving to: ‘Golden_State.pkl’
    
    100%[======================================>] 811,065     --.-K/s   in 0.02s   
    
    2020-05-08 06:38:28 (45.1 MB/s) - ‘Golden_State.pkl’ saved [811065/811065]
    



```python
file_name = "Golden_State.pkl"
games = pd.read_pickle(file_name)
games.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SEASON_ID</th>
      <th>TEAM_ID</th>
      <th>TEAM_ABBREVIATION</th>
      <th>TEAM_NAME</th>
      <th>GAME_ID</th>
      <th>GAME_DATE</th>
      <th>MATCHUP</th>
      <th>WL</th>
      <th>MIN</th>
      <th>PTS</th>
      <th>...</th>
      <th>FT_PCT</th>
      <th>OREB</th>
      <th>DREB</th>
      <th>REB</th>
      <th>AST</th>
      <th>STL</th>
      <th>BLK</th>
      <th>TOV</th>
      <th>PF</th>
      <th>PLUS_MINUS</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>22019</td>
      <td>1610612744</td>
      <td>GSW</td>
      <td>Golden State Warriors</td>
      <td>1521900066</td>
      <td>2019-07-12</td>
      <td>GSW vs. LAL</td>
      <td>L</td>
      <td>200</td>
      <td>87</td>
      <td>...</td>
      <td>0.800</td>
      <td>13.0</td>
      <td>29.0</td>
      <td>42.0</td>
      <td>13</td>
      <td>10.0</td>
      <td>3</td>
      <td>11.0</td>
      <td>21</td>
      <td>3.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>22019</td>
      <td>1610612744</td>
      <td>GSW</td>
      <td>Golden State Warriors</td>
      <td>1521900058</td>
      <td>2019-07-10</td>
      <td>GSW @ DEN</td>
      <td>W</td>
      <td>201</td>
      <td>73</td>
      <td>...</td>
      <td>0.867</td>
      <td>7.0</td>
      <td>27.0</td>
      <td>34.0</td>
      <td>10</td>
      <td>11.0</td>
      <td>7</td>
      <td>20.0</td>
      <td>20</td>
      <td>-8.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>22019</td>
      <td>1610612744</td>
      <td>GSW</td>
      <td>Golden State Warriors</td>
      <td>1521900039</td>
      <td>2019-07-08</td>
      <td>GSW @ LAL</td>
      <td>W</td>
      <td>200</td>
      <td>88</td>
      <td>...</td>
      <td>0.621</td>
      <td>8.0</td>
      <td>29.0</td>
      <td>37.0</td>
      <td>21</td>
      <td>10.0</td>
      <td>4</td>
      <td>13.0</td>
      <td>22</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>22019</td>
      <td>1610612744</td>
      <td>GSW</td>
      <td>Golden State Warriors</td>
      <td>1521900020</td>
      <td>2019-07-07</td>
      <td>GSW vs. TOR</td>
      <td>W</td>
      <td>201</td>
      <td>80</td>
      <td>...</td>
      <td>0.923</td>
      <td>6.0</td>
      <td>37.0</td>
      <td>43.0</td>
      <td>18</td>
      <td>8.0</td>
      <td>3</td>
      <td>20.0</td>
      <td>25</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>22019</td>
      <td>1610612744</td>
      <td>GSW</td>
      <td>Golden State Warriors</td>
      <td>1521900007</td>
      <td>2019-07-05</td>
      <td>GSW vs. CHA</td>
      <td>L</td>
      <td>200</td>
      <td>85</td>
      <td>...</td>
      <td>0.889</td>
      <td>8.0</td>
      <td>28.0</td>
      <td>36.0</td>
      <td>19</td>
      <td>9.0</td>
      <td>3</td>
      <td>13.0</td>
      <td>15</td>
      <td>-8.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 28 columns</p>
</div>




```python
games_home.mean()['PLUS_MINUS']
```




    3.730769230769231




```python
games_away.mean()['PLUS_MINUS']
```




    -0.6071428571428571




```python
fig, ax = plt.subplots()

games_away.plot(x='GAME_DATE',y='PLUS_MINUS', ax=ax)
games_home.plot(x='GAME_DATE',y='PLUS_MINUS', ax=ax)
ax.legend(["away", "home"])
plt.show()
```


![png](output_7_0.png)



```python
!pip install nba_api

def one_dict(list_dict):
    keys=list_dict[0].keys()
    out_dict={key:[] for key in keys}
    for dict_ in list_dict:
        for key, value in dict_.items():
            out_dict[key].append(value)
    return out_dict    

import pandas as pd
import matplotlib.pyplot as plt

from nba_api.stats.static import teams
import matplotlib.pyplot as plt

nba_teams = teams.get_teams()

dict_nba_team=one_dict(nba_teams)
df_teams=pd.DataFrame(dict_nba_team)
df_teams.head()

df_spurs=df_teams[df_teams['nickname']=='Spurs']
df_spurs
```

    Collecting nba_api
    [?25l  Downloading https://files.pythonhosted.org/packages/fd/94/ee060255b91d945297ebc2fe9a8672aee07ce83b553eef1c5ac5b974995a/nba_api-1.1.8-py3-none-any.whl (217kB)
    [K     |████████████████████████████████| 225kB 9.0MB/s eta 0:00:01
    [?25hRequirement already satisfied: requests in /opt/conda/envs/Python36/lib/python3.6/site-packages (from nba_api) (2.21.0)
    Requirement already satisfied: urllib3<1.25,>=1.21.1 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (1.24.1)
    Requirement already satisfied: chardet<3.1.0,>=3.0.2 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (3.0.4)
    Requirement already satisfied: idna<2.9,>=2.5 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2.8)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2020.4.5.1)
    Installing collected packages: nba-api
    Successfully installed nba-api-1.1.8





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>full_name</th>
      <th>abbreviation</th>
      <th>nickname</th>
      <th>city</th>
      <th>state</th>
      <th>year_founded</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>22</th>
      <td>1610612759</td>
      <td>San Antonio Spurs</td>
      <td>SAS</td>
      <td>Spurs</td>
      <td>San Antonio</td>
      <td>Texas</td>
      <td>1976</td>
    </tr>
  </tbody>
</table>
</div>




```python
from nba_api.stats.endpoints import leaguegamefinder

```


```python
nba_teams = teams.get_teams()

dict_nba_team=one_dict(nba_teams)
df_teams=pd.DataFrame(dict_nba_team)
df_teams.head()

df_bulls=df_teams[df_teams['nickname']=='Bulls']
df_bulls
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>full_name</th>
      <th>abbreviation</th>
      <th>nickname</th>
      <th>city</th>
      <th>state</th>
      <th>year_founded</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4</th>
      <td>1610612741</td>
      <td>Chicago Bulls</td>
      <td>CHI</td>
      <td>Bulls</td>
      <td>Chicago</td>
      <td>Illinois</td>
      <td>1966</td>
    </tr>
  </tbody>
</table>
</div>



## Finding NBA Teams by Abbreviation


```python
from nba_api.stats.static import teams

nba_teams = teams.get_teams()

bulls = [team for team in nba_teams if team['abbreviation'] == 'CHI'][0]
bulls_id = bulls['id']

teams.find_team_by_abbreviation('chi')
```




    {'id': 1610612741,
     'full_name': 'Chicago Bulls',
     'abbreviation': 'CHI',
     'nickname': 'Bulls',
     'city': 'Chicago',
     'state': 'Illinois',
     'year_founded': 1966}




```python
teams.find_team_by_abbreviation('dal')
```




    {'id': 1610612742,
     'full_name': 'Dallas Mavericks',
     'abbreviation': 'DAL',
     'nickname': 'Mavericks',
     'city': 'Dallas',
     'state': 'Texas',
     'year_founded': 1980}




```python
teams.find_team_by_abbreviation('SAS')
```




    {'id': 1610612759,
     'full_name': 'San Antonio Spurs',
     'abbreviation': 'SAS',
     'nickname': 'Spurs',
     'city': 'San Antonio',
     'state': 'Texas',
     'year_founded': 1976}




```python
teams.find_team_by_abbreviation('BOS')
```




    {'id': 1610612738,
     'full_name': 'Boston Celtics',
     'abbreviation': 'BOS',
     'nickname': 'Celtics',
     'city': 'Boston',
     'state': 'Massachusetts',
     'year_founded': 1946}




```python
teams.find_team_by_abbreviation('ATL')
```




    {'id': 1610612737,
     'full_name': 'Atlanta Hawks',
     'abbreviation': 'ATL',
     'nickname': 'Hawks',
     'city': 'Atlanta',
     'state': 'Atlanta',
     'year_founded': 1949}




```python
teams.find_team_by_abbreviation('PHX')
```




    {'id': 1610612756,
     'full_name': 'Phoenix Suns',
     'abbreviation': 'PHX',
     'nickname': 'Suns',
     'city': 'Phoenix',
     'state': 'Arizona',
     'year_founded': 1968}




```python
teams.find_team_by_abbreviation('SAC')
```




    {'id': 1610612758,
     'full_name': 'Sacramento Kings',
     'abbreviation': 'SAC',
     'nickname': 'Kings',
     'city': 'Sacramento',
     'state': 'California',
     'year_founded': 1948}




```python
teams.find_team_by_abbreviation('IND')
```




    {'id': 1610612754,
     'full_name': 'Indiana Pacers',
     'abbreviation': 'IND',
     'nickname': 'Pacers',
     'city': 'Indiana',
     'state': 'Indiana',
     'year_founded': 1976}




```python
teams.find_team_by_abbreviation('phi')
```




    {'id': 1610612755,
     'full_name': 'Philadelphia 76ers',
     'abbreviation': 'PHI',
     'nickname': '76ers',
     'city': 'Philadelphia',
     'state': 'Pennsylvania',
     'year_founded': 1949}



## Importing all 30 NBA Teams, scroll the list


```python
#Importing all 30 NBA Teams / scroll for a list

from nba_api.stats.static import teams
import matplotlib.pyplot as plt
teams.get_teams(

```




    [{'id': 1610612737,
      'full_name': 'Atlanta Hawks',
      'abbreviation': 'ATL',
      'nickname': 'Hawks',
      'city': 'Atlanta',
      'state': 'Atlanta',
      'year_founded': 1949},
     {'id': 1610612738,
      'full_name': 'Boston Celtics',
      'abbreviation': 'BOS',
      'nickname': 'Celtics',
      'city': 'Boston',
      'state': 'Massachusetts',
      'year_founded': 1946},
     {'id': 1610612739,
      'full_name': 'Cleveland Cavaliers',
      'abbreviation': 'CLE',
      'nickname': 'Cavaliers',
      'city': 'Cleveland',
      'state': 'Ohio',
      'year_founded': 1970},
     {'id': 1610612740,
      'full_name': 'New Orleans Pelicans',
      'abbreviation': 'NOP',
      'nickname': 'Pelicans',
      'city': 'New Orleans',
      'state': 'Louisiana',
      'year_founded': 2002},
     {'id': 1610612741,
      'full_name': 'Chicago Bulls',
      'abbreviation': 'CHI',
      'nickname': 'Bulls',
      'city': 'Chicago',
      'state': 'Illinois',
      'year_founded': 1966},
     {'id': 1610612742,
      'full_name': 'Dallas Mavericks',
      'abbreviation': 'DAL',
      'nickname': 'Mavericks',
      'city': 'Dallas',
      'state': 'Texas',
      'year_founded': 1980},
     {'id': 1610612743,
      'full_name': 'Denver Nuggets',
      'abbreviation': 'DEN',
      'nickname': 'Nuggets',
      'city': 'Denver',
      'state': 'Colorado',
      'year_founded': 1976},
     {'id': 1610612744,
      'full_name': 'Golden State Warriors',
      'abbreviation': 'GSW',
      'nickname': 'Warriors',
      'city': 'Golden State',
      'state': 'California',
      'year_founded': 1946},
     {'id': 1610612745,
      'full_name': 'Houston Rockets',
      'abbreviation': 'HOU',
      'nickname': 'Rockets',
      'city': 'Houston',
      'state': 'Texas',
      'year_founded': 1967},
     {'id': 1610612746,
      'full_name': 'Los Angeles Clippers',
      'abbreviation': 'LAC',
      'nickname': 'Clippers',
      'city': 'Los Angeles',
      'state': 'California',
      'year_founded': 1970},
     {'id': 1610612747,
      'full_name': 'Los Angeles Lakers',
      'abbreviation': 'LAL',
      'nickname': 'Lakers',
      'city': 'Los Angeles',
      'state': 'California',
      'year_founded': 1948},
     {'id': 1610612748,
      'full_name': 'Miami Heat',
      'abbreviation': 'MIA',
      'nickname': 'Heat',
      'city': 'Miami',
      'state': 'Florida',
      'year_founded': 1988},
     {'id': 1610612749,
      'full_name': 'Milwaukee Bucks',
      'abbreviation': 'MIL',
      'nickname': 'Bucks',
      'city': 'Milwaukee',
      'state': 'Wisconsin',
      'year_founded': 1968},
     {'id': 1610612750,
      'full_name': 'Minnesota Timberwolves',
      'abbreviation': 'MIN',
      'nickname': 'Timberwolves',
      'city': 'Minnesota',
      'state': 'Minnesota',
      'year_founded': 1989},
     {'id': 1610612751,
      'full_name': 'Brooklyn Nets',
      'abbreviation': 'BKN',
      'nickname': 'Nets',
      'city': 'Brooklyn',
      'state': 'New York',
      'year_founded': 1976},
     {'id': 1610612752,
      'full_name': 'New York Knicks',
      'abbreviation': 'NYK',
      'nickname': 'Knicks',
      'city': 'New York',
      'state': 'New York',
      'year_founded': 1946},
     {'id': 1610612753,
      'full_name': 'Orlando Magic',
      'abbreviation': 'ORL',
      'nickname': 'Magic',
      'city': 'Orlando',
      'state': 'Florida',
      'year_founded': 1989},
     {'id': 1610612754,
      'full_name': 'Indiana Pacers',
      'abbreviation': 'IND',
      'nickname': 'Pacers',
      'city': 'Indiana',
      'state': 'Indiana',
      'year_founded': 1976},
     {'id': 1610612755,
      'full_name': 'Philadelphia 76ers',
      'abbreviation': 'PHI',
      'nickname': '76ers',
      'city': 'Philadelphia',
      'state': 'Pennsylvania',
      'year_founded': 1949},
     {'id': 1610612756,
      'full_name': 'Phoenix Suns',
      'abbreviation': 'PHX',
      'nickname': 'Suns',
      'city': 'Phoenix',
      'state': 'Arizona',
      'year_founded': 1968},
     {'id': 1610612757,
      'full_name': 'Portland Trail Blazers',
      'abbreviation': 'POR',
      'nickname': 'Trail Blazers',
      'city': 'Portland',
      'state': 'Oregon',
      'year_founded': 1970},
     {'id': 1610612758,
      'full_name': 'Sacramento Kings',
      'abbreviation': 'SAC',
      'nickname': 'Kings',
      'city': 'Sacramento',
      'state': 'California',
      'year_founded': 1948},
     {'id': 1610612759,
      'full_name': 'San Antonio Spurs',
      'abbreviation': 'SAS',
      'nickname': 'Spurs',
      'city': 'San Antonio',
      'state': 'Texas',
      'year_founded': 1976},
     {'id': 1610612760,
      'full_name': 'Oklahoma City Thunder',
      'abbreviation': 'OKC',
      'nickname': 'Thunder',
      'city': 'Oklahoma City',
      'state': 'Oklahoma',
      'year_founded': 1967},
     {'id': 1610612761,
      'full_name': 'Toronto Raptors',
      'abbreviation': 'TOR',
      'nickname': 'Raptors',
      'city': 'Toronto',
      'state': 'Ontario',
      'year_founded': 1995},
     {'id': 1610612762,
      'full_name': 'Utah Jazz',
      'abbreviation': 'UTA',
      'nickname': 'Jazz',
      'city': 'Utah',
      'state': 'Utah',
      'year_founded': 1974},
     {'id': 1610612763,
      'full_name': 'Memphis Grizzlies',
      'abbreviation': 'MEM',
      'nickname': 'Grizzlies',
      'city': 'Memphis',
      'state': 'Tennessee',
      'year_founded': 1995},
     {'id': 1610612764,
      'full_name': 'Washington Wizards',
      'abbreviation': 'WAS',
      'nickname': 'Wizards',
      'city': 'Washington',
      'state': 'District of Columbia',
      'year_founded': 1961},
     {'id': 1610612765,
      'full_name': 'Detroit Pistons',
      'abbreviation': 'DET',
      'nickname': 'Pistons',
      'city': 'Detroit',
      'state': 'Michigan',
      'year_founded': 1948},
     {'id': 1610612766,
      'full_name': 'Charlotte Hornets',
      'abbreviation': 'CHA',
      'nickname': 'Hornets',
      'city': 'Charlotte',
      'state': 'North Carolina',
      'year_founded': 1988}]



## Let's look for some NBA Players


```python
!pip install nba_api

def one_dict(list_dict):
    keys=list_dict[0].keys()
    out_dict={key:[] for key in keys}
    for dict_ in list_dict:
        for key, value in dict_.items():
            out_dict[key].append(value)
    return out_dict    

import pandas as pd
import matplotlib.pyplot as plt

from nba_api.stats.static import players
import matplotlib.pyplot as plt

nba_players = players.get_players()
print('Number of players fetched: {}'.format(len(nba_players)))
nba_players[:100]

dict_nba_players=one_dict(nba_players)
df_players=pd.DataFrame(dict_nba_players)
df_players.head()
```

    Requirement already satisfied: nba_api in /opt/conda/envs/Python36/lib/python3.6/site-packages (1.1.8)
    Requirement already satisfied: requests in /opt/conda/envs/Python36/lib/python3.6/site-packages (from nba_api) (2.21.0)
    Requirement already satisfied: chardet<3.1.0,>=3.0.2 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (3.0.4)
    Requirement already satisfied: urllib3<1.25,>=1.21.1 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (1.24.1)
    Requirement already satisfied: idna<2.9,>=2.5 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2.8)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2020.4.5.1)
    Number of players fetched: 4501





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>full_name</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>is_active</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>76001</td>
      <td>Alaa Abdelnaby</td>
      <td>Alaa</td>
      <td>Abdelnaby</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>76002</td>
      <td>Zaid Abdul-Aziz</td>
      <td>Zaid</td>
      <td>Abdul-Aziz</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>76003</td>
      <td>Kareem Abdul-Jabbar</td>
      <td>Kareem</td>
      <td>Abdul-Jabbar</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>51</td>
      <td>Mahmoud Abdul-Rauf</td>
      <td>Mahmoud</td>
      <td>Abdul-Rauf</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1505</td>
      <td>Tariq Abdul-Wahad</td>
      <td>Tariq</td>
      <td>Abdul-Wahad</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
!pip install nba_api

from nba_api.stats.static import players
import matplotlib.pyplot as plt

big_fundamental = [player for player in nba_players
                   if player['full_name'] == 'Tim Duncan'][0]
big_fundamental

```

    Requirement already satisfied: nba_api in /opt/conda/envs/Python36/lib/python3.6/site-packages (1.1.8)
    Requirement already satisfied: requests in /opt/conda/envs/Python36/lib/python3.6/site-packages (from nba_api) (2.21.0)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2020.4.5.1)
    Requirement already satisfied: chardet<3.1.0,>=3.0.2 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (3.0.4)
    Requirement already satisfied: idna<2.9,>=2.5 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2.8)
    Requirement already satisfied: urllib3<1.25,>=1.21.1 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (1.24.1)





    {'id': 1495,
     'full_name': 'Tim Duncan',
     'first_name': 'Tim',
     'last_name': 'Duncan',
     'is_active': False}




```python
!pip install nba_api

from nba_api.stats.static import players
import matplotlib.pyplot as plt


big_fundamental = [player for player in nba_players
                   if player['full_name'] == 'Blake Griffin'][0]
big_fundamental
```

    Requirement already satisfied: nba_api in /opt/conda/envs/Python36/lib/python3.6/site-packages (1.1.8)
    Requirement already satisfied: requests in /opt/conda/envs/Python36/lib/python3.6/site-packages (from nba_api) (2.21.0)
    Requirement already satisfied: chardet<3.1.0,>=3.0.2 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (3.0.4)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2020.4.5.1)
    Requirement already satisfied: urllib3<1.25,>=1.21.1 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (1.24.1)
    Requirement already satisfied: idna<2.9,>=2.5 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2.8)





    {'id': 201933,
     'full_name': 'Blake Griffin',
     'first_name': 'Blake',
     'last_name': 'Griffin',
     'is_active': True}




```python
!pip install nba_api

from nba_api.stats.static import players
import matplotlib.pyplot as plt


big_fundamental = [player for player in nba_players
                   if player['first_name'] == 'Tim'][0]
big_fundamental
```

    Requirement already satisfied: nba_api in /opt/conda/envs/Python36/lib/python3.6/site-packages (1.1.8)
    Requirement already satisfied: requests in /opt/conda/envs/Python36/lib/python3.6/site-packages (from nba_api) (2.21.0)
    Requirement already satisfied: urllib3<1.25,>=1.21.1 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (1.24.1)
    Requirement already satisfied: idna<2.9,>=2.5 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2.8)
    Requirement already satisfied: chardet<3.1.0,>=3.0.2 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (3.0.4)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2020.4.5.1)





    {'id': 76120,
     'full_name': 'Tim Bassett',
     'first_name': 'Tim',
     'last_name': 'Bassett',
     'is_active': False}




```python
!pip install nba_api

from nba_api.stats.static import players
import matplotlib.pyplot as plt


big_fundamental = [player for player in nba_players
                   if player['last_name'] == 'James'][5]
big_fundamental
```

    Requirement already satisfied: nba_api in /opt/conda/envs/Python36/lib/python3.6/site-packages (1.1.8)
    Requirement already satisfied: requests in /opt/conda/envs/Python36/lib/python3.6/site-packages (from nba_api) (2.21.0)
    Requirement already satisfied: idna<2.9,>=2.5 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2.8)
    Requirement already satisfied: chardet<3.1.0,>=3.0.2 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (3.0.4)
    Requirement already satisfied: urllib3<1.25,>=1.21.1 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (1.24.1)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2020.4.5.1)





    {'id': 1744,
     'full_name': 'Jerome James',
     'first_name': 'Jerome',
     'last_name': 'James',
     'is_active': False}




```python
!pip install nba_api

from nba_api.stats.static import players
import matplotlib.pyplot as plt


big_fundamental = [player for player in nba_players
                   if player['last_name'] == 'James']
big_fundamental
```

    Requirement already satisfied: nba_api in /opt/conda/envs/Python36/lib/python3.6/site-packages (1.1.8)
    Requirement already satisfied: requests in /opt/conda/envs/Python36/lib/python3.6/site-packages (from nba_api) (2.21.0)
    Requirement already satisfied: urllib3<1.25,>=1.21.1 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (1.24.1)
    Requirement already satisfied: chardet<3.1.0,>=3.0.2 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (3.0.4)
    Requirement already satisfied: idna<2.9,>=2.5 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2.8)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2020.4.5.1)





    [{'id': 77115,
      'full_name': 'Aaron James',
      'first_name': 'Aaron',
      'last_name': 'James',
      'is_active': False},
     {'id': 203108,
      'full_name': 'Bernard James',
      'first_name': 'Bernard',
      'last_name': 'James',
      'is_active': False},
     {'id': 202345,
      'full_name': 'Damion James',
      'first_name': 'Damion',
      'last_name': 'James',
      'is_active': False},
     {'id': 77116,
      'full_name': 'Gene James',
      'first_name': 'Gene',
      'last_name': 'James',
      'is_active': False},
     {'id': 1080,
      'full_name': 'Henry James',
      'first_name': 'Henry',
      'last_name': 'James',
      'is_active': False},
     {'id': 1744,
      'full_name': 'Jerome James',
      'first_name': 'Jerome',
      'last_name': 'James',
      'is_active': False},
     {'id': 1629713,
      'full_name': 'Justin James',
      'first_name': 'Justin',
      'last_name': 'James',
      'is_active': True},
     {'id': 2544,
      'full_name': 'LeBron James',
      'first_name': 'LeBron',
      'last_name': 'James',
      'is_active': True},
     {'id': 2229,
      'full_name': 'Mike James',
      'first_name': 'Mike',
      'last_name': 'James',
      'is_active': False},
     {'id': 1628455,
      'full_name': 'Mike James',
      'first_name': 'Mike',
      'last_name': 'James',
      'is_active': False},
     {'id': 1906,
      'full_name': 'Tim James',
      'first_name': 'Tim',
      'last_name': 'James',
      'is_active': False}]




```python
!pip install nba_api

from nba_api.stats.static import players
import matplotlib.pyplot as plt


big_fundamental = [player for player in nba_players
                   if player['first_name'] == 'Tristan']
big_fundamental
```

    Requirement already satisfied: nba_api in /opt/conda/envs/Python36/lib/python3.6/site-packages (1.1.8)
    Requirement already satisfied: requests in /opt/conda/envs/Python36/lib/python3.6/site-packages (from nba_api) (2.21.0)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2020.4.5.1)
    Requirement already satisfied: idna<2.9,>=2.5 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2.8)
    Requirement already satisfied: urllib3<1.25,>=1.21.1 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (1.24.1)
    Requirement already satisfied: chardet<3.1.0,>=3.0.2 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (3.0.4)





    [{'id': 202684,
      'full_name': 'Tristan Thompson',
      'first_name': 'Tristan',
      'last_name': 'Thompson',
      'is_active': True}]



## Trying to find Michael Jordan in the data


```python
!pip install nba_api

from nba_api.stats.static import players
import matplotlib.pyplot as plt


big_fundamental = [player for player in nba_players
                   if player['last_name'] == 'Jordan']
big_fundamental
```

    Requirement already satisfied: nba_api in /opt/conda/envs/Python36/lib/python3.6/site-packages (1.1.8)
    Requirement already satisfied: requests in /opt/conda/envs/Python36/lib/python3.6/site-packages (from nba_api) (2.21.0)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2020.4.5.1)
    Requirement already satisfied: urllib3<1.25,>=1.21.1 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (1.24.1)
    Requirement already satisfied: chardet<3.1.0,>=3.0.2 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (3.0.4)
    Requirement already satisfied: idna<2.9,>=2.5 in /opt/conda/envs/Python36/lib/python3.6/site-packages (from requests->nba_api) (2.8)





    [{'id': 1817,
      'full_name': 'Adonis Jordan',
      'first_name': 'Adonis',
      'last_name': 'Jordan',
      'is_active': False},
     {'id': 201599,
      'full_name': 'DeAndre Jordan',
      'first_name': 'DeAndre',
      'last_name': 'Jordan',
      'is_active': True},
     {'id': 77205,
      'full_name': 'Eddie Jordan',
      'first_name': 'Eddie',
      'last_name': 'Jordan',
      'is_active': False},
     {'id': 202366,
      'full_name': 'Jerome Jordan',
      'first_name': 'Jerome',
      'last_name': 'Jordan',
      'is_active': False},
     {'id': 893,
      'full_name': 'Michael Jordan',
      'first_name': 'Michael',
      'last_name': 'Jordan',
      'is_active': False},
     {'id': 674,
      'full_name': 'Reggie Jordan',
      'first_name': 'Reggie',
      'last_name': 'Jordan',
      'is_active': False},
     {'id': 77208,
      'full_name': 'Thomas Jordan',
      'first_name': 'Thomas',
      'last_name': 'Jordan',
      'is_active': False},
     {'id': 77209,
      'full_name': 'Walter Jordan',
      'first_name': 'Walter',
      'last_name': 'Jordan',
      'is_active': False}]


